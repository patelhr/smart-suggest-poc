#!/usr/bin/env bash
set -euo pipefail
: "${GITHUB_REPO_URL:?Please set GITHUB_REPO_URL to your repo HTTPS URL}"
git init
git add .
git commit -m "feat: SmartSuggest Pro (90 modules, usage-based suggestions)"
git branch -M main
git remote add origin "$GITHUB_REPO_URL"
git push -u origin main
