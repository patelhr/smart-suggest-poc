export interface ModuleNode {
  id: string;                    // unique id (kebab-case)
  name: string;                  // "Create Order"
  route: string;                 // "/sales/orders/create-order"
  category: string;              // top-level category, e.g. "Sales"
  subcategory: string;           // e.g. "Orders"
  child: string;                 // e.g. "Create Order"
  tags?: string[];
  contextHints?: string[];       // for scoring
  description?: string;
  demoType: 'form'|'table'|'upload'|'calculator'|'kpi'|'editor'|'todo'|'selector'|'counter';
}

export interface UsageRecord {
  moduleId: string;
  count: number;
  lastUsed: number;              // epoch ms
  contexts: Record<string, number>;
}
