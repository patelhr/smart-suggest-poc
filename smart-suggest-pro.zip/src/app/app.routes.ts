import { Routes } from '@angular/router';
import { ModulePageComponent } from './pages/module-page.component';
export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'sales/orders/create-order' }
  ,{ path: 'sales/orders/create-order', component: ModulePageComponent, data: { title: 'Create Order', context: 'Sales', id: 'sales-orders-create-order' } }
  ,{ path: 'sales/orders/order-returns', component: ModulePageComponent, data: { title: 'Order Returns', context: 'Sales', id: 'sales-orders-order-returns' } }
  ,{ path: 'sales/orders/discount-calculator', component: ModulePageComponent, data: { title: 'Discount Calculator', context: 'Sales', id: 'sales-orders-discount-calculator' } }
  ,{ path: 'sales/invoices/new-invoice', component: ModulePageComponent, data: { title: 'New Invoice', context: 'Sales', id: 'sales-invoices-new-invoice' } }
  ,{ path: 'sales/invoices/invoice-list', component: ModulePageComponent, data: { title: 'Invoice List', context: 'Sales', id: 'sales-invoices-invoice-list' } }
  ,{ path: 'sales/invoices/send-reminder', component: ModulePageComponent, data: { title: 'Send Reminder', context: 'Sales', id: 'sales-invoices-send-reminder' } }
  ,{ path: 'sales/quotes/create-quote', component: ModulePageComponent, data: { title: 'Create Quote', context: 'Sales', id: 'sales-quotes-create-quote' } }
  ,{ path: 'sales/quotes/quote-list', component: ModulePageComponent, data: { title: 'Quote List', context: 'Sales', id: 'sales-quotes-quote-list' } }
  ,{ path: 'sales/quotes/convert-to-order', component: ModulePageComponent, data: { title: 'Convert to Order', context: 'Sales', id: 'sales-quotes-convert-to-order' } }
  ,{ path: 'inventory/products/add-product', component: ModulePageComponent, data: { title: 'Add Product', context: 'Inventory', id: 'inventory-products-add-product' } }
  ,{ path: 'inventory/products/product-catalog', component: ModulePageComponent, data: { title: 'Product Catalog', context: 'Inventory', id: 'inventory-products-product-catalog' } }
  ,{ path: 'inventory/products/bulk-upload', component: ModulePageComponent, data: { title: 'Bulk Upload', context: 'Inventory', id: 'inventory-products-bulk-upload' } }
  ,{ path: 'inventory/stock/stock-adjustment', component: ModulePageComponent, data: { title: 'Stock Adjustment', context: 'Inventory', id: 'inventory-stock-stock-adjustment' } }
  ,{ path: 'inventory/stock/low-stock-report', component: ModulePageComponent, data: { title: 'Low Stock Report', context: 'Inventory', id: 'inventory-stock-low-stock-report' } }
  ,{ path: 'inventory/stock/reorder-planner', component: ModulePageComponent, data: { title: 'Reorder Planner', context: 'Inventory', id: 'inventory-stock-reorder-planner' } }
  ,{ path: 'inventory/warehouses/bin-transfer', component: ModulePageComponent, data: { title: 'Bin Transfer', context: 'Inventory', id: 'inventory-warehouses-bin-transfer' } }
  ,{ path: 'inventory/warehouses/inbound-shipments', component: ModulePageComponent, data: { title: 'Inbound Shipments', context: 'Inventory', id: 'inventory-warehouses-inbound-shipments' } }
  ,{ path: 'inventory/warehouses/outbound-shipments', component: ModulePageComponent, data: { title: 'Outbound Shipments', context: 'Inventory', id: 'inventory-warehouses-outbound-shipments' } }
  ,{ path: 'customers/crm/add-contact', component: ModulePageComponent, data: { title: 'Add Contact', context: 'Customers', id: 'customers-crm-add-contact' } }
  ,{ path: 'customers/crm/contact-list', component: ModulePageComponent, data: { title: 'Contact List', context: 'Customers', id: 'customers-crm-contact-list' } }
  ,{ path: 'customers/crm/import-leads', component: ModulePageComponent, data: { title: 'Import Leads', context: 'Customers', id: 'customers-crm-import-leads' } }
  ,{ path: 'customers/accounts/create-account', component: ModulePageComponent, data: { title: 'Create Account', context: 'Customers', id: 'customers-accounts-create-account' } }
  ,{ path: 'customers/accounts/account-directory', component: ModulePageComponent, data: { title: 'Account Directory', context: 'Customers', id: 'customers-accounts-account-directory' } }
  ,{ path: 'customers/accounts/merge-duplicates', component: ModulePageComponent, data: { title: 'Merge Duplicates', context: 'Customers', id: 'customers-accounts-merge-duplicates' } }
  ,{ path: 'customers/engagement/send-email', component: ModulePageComponent, data: { title: 'Send Email', context: 'Customers', id: 'customers-engagement-send-email' } }
  ,{ path: 'customers/engagement/call-log', component: ModulePageComponent, data: { title: 'Call Log', context: 'Customers', id: 'customers-engagement-call-log' } }
  ,{ path: 'customers/engagement/tasks', component: ModulePageComponent, data: { title: 'Tasks', context: 'Customers', id: 'customers-engagement-tasks' } }
  ,{ path: 'finance/expenses/log-expense', component: ModulePageComponent, data: { title: 'Log Expense', context: 'Finance', id: 'finance-expenses-log-expense' } }
  ,{ path: 'finance/expenses/expense-report', component: ModulePageComponent, data: { title: 'Expense Report', context: 'Finance', id: 'finance-expenses-expense-report' } }
  ,{ path: 'finance/expenses/export-csv', component: ModulePageComponent, data: { title: 'Export CSV', context: 'Finance', id: 'finance-expenses-export-csv' } }
  ,{ path: 'finance/payments/record-payment', component: ModulePageComponent, data: { title: 'Record Payment', context: 'Finance', id: 'finance-payments-record-payment' } }
  ,{ path: 'finance/payments/payouts', component: ModulePageComponent, data: { title: 'Payouts', context: 'Finance', id: 'finance-payments-payouts' } }
  ,{ path: 'finance/payments/reconcile', component: ModulePageComponent, data: { title: 'Reconcile', context: 'Finance', id: 'finance-payments-reconcile' } }
  ,{ path: 'finance/budgets/create-budget', component: ModulePageComponent, data: { title: 'Create Budget', context: 'Finance', id: 'finance-budgets-create-budget' } }
  ,{ path: 'finance/budgets/budget-vs-actuals', component: ModulePageComponent, data: { title: 'Budget vs Actuals', context: 'Finance', id: 'finance-budgets-budget-vs-actuals' } }
  ,{ path: 'finance/budgets/adjust-allocation', component: ModulePageComponent, data: { title: 'Adjust Allocation', context: 'Finance', id: 'finance-budgets-adjust-allocation' } }
  ,{ path: 'hr/recruitment/post-job', component: ModulePageComponent, data: { title: 'Post Job', context: 'HR', id: 'hr-recruitment-post-job' } }
  ,{ path: 'hr/recruitment/candidate-list', component: ModulePageComponent, data: { title: 'Candidate List', context: 'HR', id: 'hr-recruitment-candidate-list' } }
  ,{ path: 'hr/recruitment/schedule-interview', component: ModulePageComponent, data: { title: 'Schedule Interview', context: 'HR', id: 'hr-recruitment-schedule-interview' } }
  ,{ path: 'hr/employees/add-employee', component: ModulePageComponent, data: { title: 'Add Employee', context: 'HR', id: 'hr-employees-add-employee' } }
  ,{ path: 'hr/employees/employee-directory', component: ModulePageComponent, data: { title: 'Employee Directory', context: 'HR', id: 'hr-employees-employee-directory' } }
  ,{ path: 'hr/employees/leave-requests', component: ModulePageComponent, data: { title: 'Leave Requests', context: 'HR', id: 'hr-employees-leave-requests' } }
  ,{ path: 'hr/payroll/run-payroll', component: ModulePageComponent, data: { title: 'Run Payroll', context: 'HR', id: 'hr-payroll-run-payroll' } }
  ,{ path: 'hr/payroll/salary-slips', component: ModulePageComponent, data: { title: 'Salary Slips', context: 'HR', id: 'hr-payroll-salary-slips' } }
  ,{ path: 'hr/payroll/tax-declarations', component: ModulePageComponent, data: { title: 'Tax Declarations', context: 'HR', id: 'hr-payroll-tax-declarations' } }
  ,{ path: 'operations/logistics/create-shipment', component: ModulePageComponent, data: { title: 'Create Shipment', context: 'Operations', id: 'operations-logistics-create-shipment' } }
  ,{ path: 'operations/logistics/track-shipment', component: ModulePageComponent, data: { title: 'Track Shipment', context: 'Operations', id: 'operations-logistics-track-shipment' } }
  ,{ path: 'operations/logistics/delivery-exceptions', component: ModulePageComponent, data: { title: 'Delivery Exceptions', context: 'Operations', id: 'operations-logistics-delivery-exceptions' } }
  ,{ path: 'operations/procurement/new-purchase-order', component: ModulePageComponent, data: { title: 'New Purchase Order', context: 'Operations', id: 'operations-procurement-new-purchase-order' } }
  ,{ path: 'operations/procurement/po-list', component: ModulePageComponent, data: { title: 'PO List', context: 'Operations', id: 'operations-procurement-po-list' } }
  ,{ path: 'operations/procurement/vendor-comparison', component: ModulePageComponent, data: { title: 'Vendor Comparison', context: 'Operations', id: 'operations-procurement-vendor-comparison' } }
  ,{ path: 'operations/quality/qc-checklist', component: ModulePageComponent, data: { title: 'QC Checklist', context: 'Operations', id: 'operations-quality-qc-checklist' } }
  ,{ path: 'operations/quality/defect-log', component: ModulePageComponent, data: { title: 'Defect Log', context: 'Operations', id: 'operations-quality-defect-log' } }
  ,{ path: 'operations/quality/capa-form', component: ModulePageComponent, data: { title: 'CAPA Form', context: 'Operations', id: 'operations-quality-capa-form' } }
  ,{ path: 'marketing/campaigns/create-campaign', component: ModulePageComponent, data: { title: 'Create Campaign', context: 'Marketing', id: 'marketing-campaigns-create-campaign' } }
  ,{ path: 'marketing/campaigns/campaign-analytics', component: ModulePageComponent, data: { title: 'Campaign Analytics', context: 'Marketing', id: 'marketing-campaigns-campaign-analytics' } }
  ,{ path: 'marketing/campaigns/audience-selector', component: ModulePageComponent, data: { title: 'Audience Selector', context: 'Marketing', id: 'marketing-campaigns-audience-selector' } }
  ,{ path: 'marketing/content/asset-library', component: ModulePageComponent, data: { title: 'Asset Library', context: 'Marketing', id: 'marketing-content-asset-library' } }
  ,{ path: 'marketing/content/upload-asset', component: ModulePageComponent, data: { title: 'Upload Asset', context: 'Marketing', id: 'marketing-content-upload-asset' } }
  ,{ path: 'marketing/content/content-calendar', component: ModulePageComponent, data: { title: 'Content Calendar', context: 'Marketing', id: 'marketing-content-content-calendar' } }
  ,{ path: 'marketing/seo/keyword-planner', component: ModulePageComponent, data: { title: 'Keyword Planner', context: 'Marketing', id: 'marketing-seo-keyword-planner' } }
  ,{ path: 'marketing/seo/backlink-list', component: ModulePageComponent, data: { title: 'Backlink List', context: 'Marketing', id: 'marketing-seo-backlink-list' } }
  ,{ path: 'marketing/seo/site-audit-notes', component: ModulePageComponent, data: { title: 'Site Audit Notes', context: 'Marketing', id: 'marketing-seo-site-audit-notes' } }
  ,{ path: 'support/tickets/new-ticket', component: ModulePageComponent, data: { title: 'New Ticket', context: 'Support', id: 'support-tickets-new-ticket' } }
  ,{ path: 'support/tickets/ticket-queue', component: ModulePageComponent, data: { title: 'Ticket Queue', context: 'Support', id: 'support-tickets-ticket-queue' } }
  ,{ path: 'support/tickets/sla-dashboard', component: ModulePageComponent, data: { title: 'SLA Dashboard', context: 'Support', id: 'support-tickets-sla-dashboard' } }
  ,{ path: 'support/knowledge-base/new-article', component: ModulePageComponent, data: { title: 'New Article', context: 'Support', id: 'support-knowledge-base-new-article' } }
  ,{ path: 'support/knowledge-base/article-list', component: ModulePageComponent, data: { title: 'Article List', context: 'Support', id: 'support-knowledge-base-article-list' } }
  ,{ path: 'support/knowledge-base/import-articles', component: ModulePageComponent, data: { title: 'Import Articles', context: 'Support', id: 'support-knowledge-base-import-articles' } }
  ,{ path: 'support/feedback/nps-survey', component: ModulePageComponent, data: { title: 'NPS Survey', context: 'Support', id: 'support-feedback-nps-survey' } }
  ,{ path: 'support/feedback/responses', component: ModulePageComponent, data: { title: 'Responses', context: 'Support', id: 'support-feedback-responses' } }
  ,{ path: 'support/feedback/feature-requests', component: ModulePageComponent, data: { title: 'Feature Requests', context: 'Support', id: 'support-feedback-feature-requests' } }
  ,{ path: 'analytics/dashboards/sales-kpis', component: ModulePageComponent, data: { title: 'Sales KPIs', context: 'Analytics', id: 'analytics-dashboards-sales-kpis' } }
  ,{ path: 'analytics/dashboards/cohort-analysis', component: ModulePageComponent, data: { title: 'Cohort Analysis', context: 'Analytics', id: 'analytics-dashboards-cohort-analysis' } }
  ,{ path: 'analytics/dashboards/funnel-overview', component: ModulePageComponent, data: { title: 'Funnel Overview', context: 'Analytics', id: 'analytics-dashboards-funnel-overview' } }
  ,{ path: 'analytics/reports/ad-hoc-query', component: ModulePageComponent, data: { title: 'Ad-hoc Query', context: 'Analytics', id: 'analytics-reports-ad-hoc-query' } }
  ,{ path: 'analytics/reports/report-library', component: ModulePageComponent, data: { title: 'Report Library', context: 'Analytics', id: 'analytics-reports-report-library' } }
  ,{ path: 'analytics/reports/schedule-report', component: ModulePageComponent, data: { title: 'Schedule Report', context: 'Analytics', id: 'analytics-reports-schedule-report' } }
  ,{ path: 'analytics/data/upload-csv', component: ModulePageComponent, data: { title: 'Upload CSV', context: 'Analytics', id: 'analytics-data-upload-csv' } }
  ,{ path: 'analytics/data/model-monitor', component: ModulePageComponent, data: { title: 'Model Monitor', context: 'Analytics', id: 'analytics-data-model-monitor' } }
  ,{ path: 'analytics/data/field-mapping', component: ModulePageComponent, data: { title: 'Field Mapping', context: 'Analytics', id: 'analytics-data-field-mapping' } }
  ,{ path: 'settings/security/change-password', component: ModulePageComponent, data: { title: 'Change Password', context: 'Settings', id: 'settings-security-change-password' } }
  ,{ path: 'settings/security/api-keys', component: ModulePageComponent, data: { title: 'API Keys', context: 'Settings', id: 'settings-security-api-keys' } }
  ,{ path: 'settings/security/user-roles', component: ModulePageComponent, data: { title: 'User Roles', context: 'Settings', id: 'settings-security-user-roles' } }
  ,{ path: 'settings/organization/company-profile', component: ModulePageComponent, data: { title: 'Company Profile', context: 'Settings', id: 'settings-organization-company-profile' } }
  ,{ path: 'settings/organization/billing-settings', component: ModulePageComponent, data: { title: 'Billing Settings', context: 'Settings', id: 'settings-organization-billing-settings' } }
  ,{ path: 'settings/organization/audit-logs', component: ModulePageComponent, data: { title: 'Audit Logs', context: 'Settings', id: 'settings-organization-audit-logs' } }
  ,{ path: 'settings/preferences/theme', component: ModulePageComponent, data: { title: 'Theme', context: 'Settings', id: 'settings-preferences-theme' } }
  ,{ path: 'settings/preferences/notifications', component: ModulePageComponent, data: { title: 'Notifications', context: 'Settings', id: 'settings-preferences-notifications' } }
  ,{ path: 'settings/preferences/localization', component: ModulePageComponent, data: { title: 'Localization', context: 'Settings', id: 'settings-preferences-localization' } }
  ,{ path: '**', redirectTo: 'sales/orders/create-order' }
