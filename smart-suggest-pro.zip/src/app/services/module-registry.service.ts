import { Injectable } from '@angular/core';
import { ALL_MODULES } from '../data/nav';
import { ModuleNode } from '../models';

@Injectable({ providedIn: 'root' })
export class ModuleRegistryService {
  getAll(): ModuleNode[] { return Array.from(ALL_MODULES); }
  byId(id: string): ModuleNode | undefined { return this.getAll().find(m => m.id === id); }
}
