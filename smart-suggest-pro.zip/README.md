# SmartSuggest Pro (Angular 17)

**90 feature modules** organized as **10 categories × 3 sub-categories × 3 child modules**, with:
- Left-side nested navigation (category → sub → child)
- Global search that ranks results using a **usage + recency + context** scoring engine
- Contextual **"Suggested for you"** chips updating as users interact
- Dynamic **ModulePage** that renders different demo UIs (form/table/upload/calculator/kpi/editor/todo/selector/counter)
- Usage recorded to `localStorage` for persistence across refreshes

## Run
```bash
npm i -g @angular/cli
npm install
ng serve
# open http://localhost:4200
```

## How it works
- `src/app/data/nav.ts` defines all 90 modules and grouped nav structure.
- `src/app/services/usage.service.ts` persists usage (count, lastUsed, per-context counts).
- `src/app/services/suggestion.service.ts` computes score:
  - `score = 0.7 * frequencyNorm + 0.2 * recency + 0.1 * contextFit + queryBoost`
  - Recency uses a **7-day half-life** exponential decay.
- `src/app/pages/module-page.component.ts` renders a demo UI based on `demoType` and records usage on interactions.
- `src/app/app.routes.ts` includes a static route for every module with `data.id` + `data.context`.

## Push to GitHub
1. Create an empty repo at GitHub (e.g., `smart-suggest-pro`).
2. In this folder:
   ```bash
   git init
   git add .
   git commit -m "feat: SmartSuggest Pro (90 modules, usage-based suggestions)"
   git branch -M main
   git remote add origin https://github.com/<YOUR_USER>/smart-suggest-pro.git
   git push -u origin main
   ```

## Customize
- Edit `src/app/data/nav.ts` to rename categories, subs, or child modules and to change `demoType`.
- Tweak scoring half-life and weights in `suggestion.service.ts`.
- Add guards/auth, theming, or a real backend later.

**Note:** This project pins Angular 17 and imports `zone.js` to avoid common setup errors.
